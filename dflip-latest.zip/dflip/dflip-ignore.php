<?php
// @formatter:off
/**
 * Plugin Name: DearFlip 3D FlipBook
 * Description: Create Realistic 3D Flip-books using jQuery
 *
 * Version: 2.2.54
 * Update URI: https://api.freemius.com
 *
 * Text Domain: DFLIP
 * Author: DearHive
 * Author URI: https://dearhive.com/
 *
 */


//This file is not required and can be ignored
