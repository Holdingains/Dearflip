=== dFlip 3D Flipbook ===
Contributors: dearhive
Tags: flipbook, 3d flipbook, pdf viewer, pdf, pdf flipbook, pdf embed
Requires at least: 3.0.1
Tested up to: 5.4
Stable tag: 1.5.6
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html